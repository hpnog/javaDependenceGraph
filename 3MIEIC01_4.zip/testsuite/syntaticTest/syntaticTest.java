package pdg;

public class teste2 {
	void sum() {
		int i; 
		int sum
		sum = 0;
		i = 1;
		while(i < 11){
			sum = sum + i;
			i = i + 1;
		}
	}
}
