# If Test

This test was designed to show how our program outputs the graph of a Java file containing If clauses.
No errors should be displayed onthe console and the file's PDG is displayed.
Note the If clause's representation on the PDG.
