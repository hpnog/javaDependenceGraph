# Nested Cycle Test

This test was designed to show how our program outputs the graph of a Java file containing several cycles, nested or not.

No errors should be displayed onthe console and the file's PDG is displayed.
Note the loops' representation on the PDG.
