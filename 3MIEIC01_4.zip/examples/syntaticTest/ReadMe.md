# Syntatic Analysis

This test was specifically designed to showcase the syntatic error reporting capabilities of our tool and as such it has a simple syntatic error.

As our syntatic analysis is based on an external tool (JavaParser), the analysis stops after the first error is detected.

The detected error is shown on the console.
