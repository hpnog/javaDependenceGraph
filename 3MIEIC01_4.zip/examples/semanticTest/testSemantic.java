import java.util.Hashtable;

public class test extends Tempo {

	int integer1 = 2;
	String stringtest1;
	int integer2;
	
	private int pointlessfunction(int wt){
    	int c = 0;
		char b = 'b';
		String d,e,a;
		t++;
		pointlessfunction(test);
		pointlessfunction(c,b);
		pointlessfunction(integer1);
		if(m==3)
		c=2+(int)b+h;
		while(c==0){
		String l;
		c=1;
		}
		int i;
		for(i=0;i<3;i++)
		c++;
		long t;
		String d,e;
    	return a=a+2;
    }
    
	public static void main(String[] args) {
		MyClass newvar;
        System.out.println("Hello, World");
		pointlessfunction(newvar,wut,this.asd);
		seriousFunction(f);
		MyClass.seriousFunction(2);
		someclass.seriousFunction();
		someclass.test1(newvar);
		return newvar;
    }

    
}

public class MyClass {
	int ble;
	public void seriousFunction(){
		return;
	}
	public void testfun(int a, String b)
	{}
}

