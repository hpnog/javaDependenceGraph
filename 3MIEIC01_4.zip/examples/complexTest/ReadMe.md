# Simple Test

This test was designed to show how our program outputs the graph of a complex Java file.
No errors should be displayed on the console and the file's PDG is displayed.
